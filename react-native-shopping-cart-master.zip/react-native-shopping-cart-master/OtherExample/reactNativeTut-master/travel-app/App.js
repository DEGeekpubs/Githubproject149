import React from 'react';
import { createAppContainer } from 'react-navigation';
import Travel from './navigation/Travel';

export default createAppContainer(Travel);