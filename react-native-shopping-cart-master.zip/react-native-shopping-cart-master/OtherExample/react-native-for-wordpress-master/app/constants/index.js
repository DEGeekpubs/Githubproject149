import * as theme from './theme';
import * as mocks from './mocks';

export {
  theme,
  mocks,
};