

# home 
<img src="https://github.com/stnc/ReactNative-Navigation-Tut/blob/master/example_img/n1.png?raw=true" alt="home.png">

# news screen
<img src="https://github.com/stnc/ReactNative-Navigation-Tut/blob/master/example_img/n2.png?raw=true" alt="electoinc.png">

# edit screen
<img src="https://github.com/stnc/ReactNative-Navigation-Tut/blob/master/example_img/n3.png?raw=true" alt="card.png">

