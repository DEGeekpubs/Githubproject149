React Native Quiz App

##  latest version 

https://github.com/stnc/react-native-quiz/tree/v2.5

<img src="https://github.com/stnc/react-native-quiz/blob/v2.5/dummy/qv2.5_12.png?raw=true" alt="qv2.5_12.png">

<img src="https://github.com/stnc/react-native-quiz/blob/v2.5/dummy/qv2.5_1.png?raw=true" alt="qv2.5_1.png">



## version 1 

https://github.com/stnc/react-native-quiz/tree/v2.0

<img src="https://github.com/stnc/react-native-quiz/blob/master/dummy/quizv1.0.png?raw=true" alt="quizv1.0.png">


A simple cross platform (iOS and Android) React Native quiz app. 

This example was put together for React Native by Example. 

Get started learning & mastering React Native for free!

sources 
http://nobrok.com/create-a-quiz-app-using-react-native/

