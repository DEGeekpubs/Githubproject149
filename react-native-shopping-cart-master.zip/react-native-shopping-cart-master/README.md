# react native shopping cart (react native navigation and redux shopping cart)

react native shopping cart

react native navigation and redux shopping cart

# IMAGEs 

## home 
<img src="https://github.com/stnc/react-native-shopping-cart/blob/master/img/home.png?raw=true" alt="home.png">

# product screen
<img src="https://github.com/stnc/react-native-shopping-cart/blob/master/img/electoinc.png?raw=true" alt="electoinc.png">

# card screen
<img src="https://github.com/stnc/react-native-shopping-cart/blob/master/img/card2.png?raw=true" alt="card.png">

